// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
 
  // export const ENV = {
//   production: false,
//   firebase: {
//     apiKey: "AIzaSyCWmZSKBJlWWAm0Mo0TQatmwyIlGq968T0",
//     authDomain: "reparto-9bb51.firebaseapp.com",
//     databaseURL: "https://reparto-9bb51.firebaseio.com",
//     projectId: "reparto-9bb51",
//     storageBucket: "",
//     messagingSenderId: "717489812128"
//   }
// }



  production: false,
  firebase: {
    apiKey: "AIzaSyALT1Q9KuooFol_FgOKgxq89gzEfKog9Sw",
    authDomain: "arrobaredamigos.firebaseapp.com",
    databaseURL: "https://arrobaredamigos.firebaseio.com",
    projectId: "arrobaredamigos",
    storageBucket: "arrobaredamigos.appspot.com",
    messagingSenderId: "1051206126026"
  }
}


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
