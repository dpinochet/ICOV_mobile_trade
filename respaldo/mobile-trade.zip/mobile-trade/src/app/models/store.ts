export interface Store {
    id: number;
    name_business: string;
    id_multistore: number;
    subsidiary_publish__photo: any;
    subsidiary_publish__created_at?: string;
}
